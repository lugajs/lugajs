describe("luga.data.widgets.PagingBar", function(){

	"use strict";

	it("Is the PagingBar class", function(){
		expect(jQuery.isFunction(luga.data.widgets.PagingBar)).toEqual(true);
	});


});