jasmine.DEFAULT_TIMEOUT_INTERVAL = 10000;
jasmine.getFixtures().fixturesPath = "fixtures";
jasmine.getJSONFixtures().fixturesPath = "fixtures";