jasmine.DEFAULT_TIMEOUT_INTERVAL = 10000;
jasmine.getFixtures().fixturesPath = "base/test/fixtures";
jasmine.getJSONFixtures().fixturesPath = "base/test/fixtures";

var LUGA_TEST_XHR_BASE = "base/test/";