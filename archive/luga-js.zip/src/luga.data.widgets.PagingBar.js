(function(){
	"use strict";

	luga.namespace("luga.data.widgets");

	/**
	 * @typedef {String} luga.data.luga.data.widgets.PAGING_STYLE
	 * @enum {String}
	 */
	luga.data.widgets.PAGING_STYLE = {
		LINKS: "links",
		PAGES: "pages"
	};

	luga.data.widgets.PagingBar = function(options){

		var CONST = {
			SAFE_HREF: "javascript:;",
			LINKS_SEPARATOR: " - "
		};

		// TODO: validate options
		// TODO: enum for style

		this.config = {
			/** @type {luga.data.PagedView} */
			pagedView: undefined,
			/** @type {Element} */
			node: undefined,
			style: "links",
			nextText: ">",
			prevText: "<",
			separator: " | ",
			maxLinks: 20
		};
		luga.merge(this.config, options);

		/**
		 * @type {luga.data.widgets.PagingBar}
		 */
		var self = this;
		// Alias/shortcuts
		var pagedView = self.config.pagedView;
		var node = self.config.node;

		pagedView.addObserver(this);

		var render = function(){
			// Reset UI
			node.innerHTML = "";

			var currentPageIndex = pagedView.getCurrentPageIndex();

			if(pagedView.getPagesCount() > 1){
				renderPrevLink(self.config.prevText, currentPageIndex);
				renderMainLinks(self.config.maxLinks, self.config.style);
				renderNextLink(self.config.nextText, currentPageIndex);
			}
		};

		var renderPrevLink = function(text, pageIndex){

			var textNode = document.createTextNode(text);
			var linkNode = document.createElement("a");
			linkNode.setAttribute("href", CONST.SAFE_HREF);
			addGoToPageEvent(linkNode, pageIndex - 1);

			linkNode.appendChild(textNode);

			if(pageIndex !== 1){
				node.appendChild(linkNode);
			}
			else{
				node.appendChild(textNode);
			}

			node.appendChild(document.createTextNode(" "));
		};

		var renderNextLink = function(text, pageIndex){
			node.appendChild(document.createTextNode(" "));
			var textNode = document.createTextNode(text);
			var linkNode = document.createElement("a");
			linkNode.setAttribute("href", CONST.SAFE_HREF);
			addGoToPageEvent(linkNode, pageIndex + 1);

			linkNode.appendChild(textNode);

			if(pageIndex !== pagedView.getPagesCount()){
				node.appendChild(linkNode);
			}
			else{
				node.appendChild(textNode);
			}
		};

		var renderMainLinks = function(maxLinks, style){
			// TODO: Review local vars
			var pageSize = pagedView.getPageSize();
			var recordsCount = pagedView.getRecordsCount();
			var pagesCount = pagedView.getPagesCount();
			var currentPageIndex = pagedView.getCurrentPageIndex();

			var endIndex = getEndIndex(currentPageIndex, maxLinks, pagesCount);

			// Page numbers are between 1 and n. So the loop start from 1
			for(var i = 1; i < (endIndex + 1); i++){

				var linkText = getLinkText(i, style, pageSize, pagesCount, recordsCount);
				if(i !== currentPageIndex){
					renderCurrentLink(i, linkText);
				}
				else{
					// No link on current page
					renderCurrenText(linkText);
				}
				// No separator on last entry
				if(i < endIndex){
					renderSeparator();
				}
			}

		};

		var renderCurrentLink = function(i, linkText){
			var textNode = document.createTextNode(linkText);
			var linkNode = document.createElement("a");
			linkNode.appendChild(textNode);
			linkNode.setAttribute("href", CONST.SAFE_HREF);
			addGoToPageEvent(linkNode, i);
			node.appendChild(linkNode);
		};

		var renderCurrenText = function(linkText){
			var textNode = document.createTextNode(linkText);
			var strongNode = document.createElement("strong");
			strongNode.appendChild(textNode);
			node.appendChild(strongNode);
		};

		var renderSeparator = function(){
			var separatorNode = document.createTextNode(self.config.separator);
			node.appendChild(separatorNode);
		};

		var addGoToPageEvent = function(linkNode, pageNumber){
			linkNode.addEventListener("click", function(event){
				event.preventDefault();
				pagedView.goToPage(pageNumber);
			});
		};

		var getEndIndex = function(currentPageIndex, maxLinks, pagesCount){
			var startIndex = parseInt(currentPageIndex - parseInt(maxLinks / 2));
			if(startIndex < 1){
				startIndex = 1;
			}
			var tempPos = startIndex + maxLinks - 1;
			var endIndex = pagesCount;
			if(tempPos < pagesCount){
				endIndex = tempPos;
			}
			return endIndex;
		};

		var getLinkText = function(i, style, pageSize, pagesCount, recordsCount){
			var linkText = "";

			if(style === luga.data.widgets.PAGING_STYLE.PAGES){
				linkText = i;
			}

			if(style === luga.data.widgets.PAGING_STYLE.LINKS){
				var start = "";
				var end = "";
				if(i !== 1){
					start = (pageSize * (i - 1)) + 1;
				}
				else{
					// First link
					start = 1;
				}
				if(i < pagesCount){
					end = start + pageSize - 1;
				}
				else{
					// Last link
					end = recordsCount;
				}
				linkText = start + CONST.LINKS_SEPARATOR + end;
			}

			return linkText;
		};

		/* Events Handlers */

		/**
		 * @param {luga.data.dataSourceChanged} data
		 */
		this.onDataChangedHandler = function(data){
			render();
		};


	};

}());