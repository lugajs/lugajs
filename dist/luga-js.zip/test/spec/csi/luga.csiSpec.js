describe("luga.csi", function(){

	it("Lives inside its own namespace", function(){
		expect(luga.csi).toBeDefined();
	});

});